package common;

public class Pager {
	 
    /**
     * ��ǰҳ��
     */
    private int currentPage = 1;
    /**
     * �ܼ�¼��
     */
    private int totalResults = 0;
    /**
     * ÿҳ��¼��
     */
    private int pageSize = 10;
 
    /**
     * ʵ������ҳbean
     */
    public Pager() { }
 
    /**
     * @param currentPage ��ǰҳ��
     * @param totalResults �ܼ�¼��
     * @param pageSize ÿҳ��¼��
     */
    public Pager(int currentPage, int totalResults, int pageSize) {
        this.currentPage = currentPage;
        this.totalResults = totalResults;
        this.pageSize = pageSize;
    }
 
    /**
     * @return ��ǰҳ��
     */
    public int getCurrentPage() {
        return currentPage;
    }
 
    /**
     * @param currentPage ��ǰҳ��
     */
    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }
 
    /**
     * @return ��ҳ��
     */
    public int getTotalPages() {
        return (int) Math.ceil(totalResults / (double) pageSize);
    }
 
    /**
     * @return ��ʼ��¼��
     */
    public int getStartResults() {
        return (currentPage - 1) * pageSize;
    }
 
    /**
     * @return �ܼ�¼��
     */
    public int getTotalResults() {
        return totalResults;
    }
 
    /**
     * @param totalResults �ܼ�¼��
     */
    public void setTotalResults(int totalResults) {
        this.totalResults = totalResults;
    }
 
    /**
     * @return ÿҳ��¼��
     */
    public int getPageSize() {
        return pageSize;
    }
 
    /**
     * @param pageSize ÿҳ��¼��
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
 
    /**
     * @return �Ƿ�����ҳ
     */
    public boolean hasPrevPages() {
        return currentPage > 1;
    }
 
    /**
     * @return �Ƿ�����ҳ
     */
    public boolean hasNextPages() {
        return currentPage < getTotalPages();
    }
 
}
