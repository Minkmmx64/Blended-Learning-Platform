package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyConn {
	private static Connection con;

	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");

			String url = "jdbc:mysql://localhost:3306/itcaststore?useUnicode=true&characterEncoding=utf-8";
			String username = "root";
			String password = "root";
			con = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public static void release(Statement stat,Connection con){
		if(stat!=null){
			try{
				stat.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			stat=null;
		}
		if(con!=null){
			try{
				con.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			con=null;
		}
	}
	public static void release(ResultSet rs,Statement stat,Connection con){
		if(rs!=null){
			try{
				rs.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			rs=null;
		}
		if(stat!=null){
			try{
				stat.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			stat=null;
		}
		if(con!=null){
			try{
				con.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			con=null;
		}
	}

}
