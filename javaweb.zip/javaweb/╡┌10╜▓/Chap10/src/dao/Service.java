package dao;

import java.util.List;

import javax.servlet.annotation.WebServlet;

import javabean.PageBean;
import javabean.User;

public class Service {
	public PageBean<User> findAll(int pageNum, int pageSize) {
		 UserDao2 userDao = new UserDao2();
		 List<User> users = userDao.findAll();
		 int totalRecord = users.size();
		 PageBean<User> pb = new PageBean<>(pageNum, pageSize, totalRecord);
		 pb.setList(users);
		 return pb;
		 }

}
