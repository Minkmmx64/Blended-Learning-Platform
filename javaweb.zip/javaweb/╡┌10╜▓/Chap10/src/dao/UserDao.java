package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javabean.User;
import database.MyConn;

public class UserDao {
	private Connection con=null;
	private Statement stat=null;
	private ResultSet rs=null;

	public ArrayList<User> findAll(){//��ʾ�����û���Ϣ
		ArrayList<User> list=new ArrayList<User>();		
		try{
			con=MyConn.getConnection();
			stat=con.createStatement();
			String sql="select * from user";
			rs=stat.executeQuery(sql);
			while(rs.next()){
				User user=new User();
				user.setId(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setGender(rs.getString(4));
				user.setEmail(rs.getString(5));
				user.setTelephone(rs.getString(6));
				list.add(user);
			}
			return list;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(rs, stat, con);
		}
		return null;
	}
	public User findByName(String name){//ͨ���û�����ѯ
		User user=new User();
		try{
			con=MyConn.getConnection();
			stat=con.createStatement();
			String sql="select * from user where username='"+name+"'";
			rs=stat.executeQuery(sql);
			while(rs.next()){
				user.setUsername(rs.getString(2));
				user.setGender(rs.getString(4));
				user.setEmail(rs.getString(5));
				user.setTelephone(rs.getString(6));
			}
			return user;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(rs, stat, con);
		}
		return null;
	}
	public boolean insert(User user){//�����û���Ϣ
		try{
			con=MyConn.getConnection();
			stat=con.createStatement();
			String sql="insert into user(username,PASSWORD,gender,email,telephone,introduce) values('"+user.getUsername()+"','"+user.getPassword()+"','"+user.getGender()+"','"+user.getEmail()+"','"+user.getTelephone()+"','"+user.getIntroduce()+"')";
			if(stat.executeUpdate(sql)==1) return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(stat, con);
		}
		return false;
	}
	public boolean update(User user){//�޸��û���Ϣ
		try{
			con=MyConn.getConnection();
			stat=con.createStatement();
			String sql="update user set gender='"+user.getGender()+"',PASSWORD='"+user.getPassword()+"',email='"+user.getEmail()+"',introduce='"+user.getIntroduce()+"',telephone='"+user.getTelephone()+"' where username='"+user.getUsername()+"'";
			if(stat.executeUpdate(sql)==1) return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(stat, con);
		}
		return false;
	}
	public boolean delete(String name){//ɾ���û���Ϣ
		try{
			con=MyConn.getConnection();
			stat=con.createStatement();
			String sql="delete from user where username='"+name+"'";
			if(stat.executeUpdate(sql)==1)
			   return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(stat, con);
		}
		return false;
	}
	public  boolean login(String username, String pwd){//��¼
		try{
			con=MyConn.getConnection();
			stat=con.createStatement();
			String sql="select * from user where username='"+username+"'and PASSWORD='"+pwd+"'";
			rs=stat.executeQuery(sql);		
			if(rs.next())
			   return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(stat, con);
		}
		return false;
	}
}
