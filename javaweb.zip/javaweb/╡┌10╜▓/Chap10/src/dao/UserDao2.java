package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javabean.User;
import database.MyConn;

public class UserDao2 {
	private Connection con=null;
	PreparedStatement preStat=null;
	private ResultSet rs=null;

	public ArrayList<User> findAll(){
		ArrayList<User> list=new ArrayList<User>();		
		String sql = "SELECT * FROM user";
		 con = MyConn.getConnection();
		try{
			preStat=con.prepareStatement(sql);
			rs=preStat.executeQuery();
			while(rs.next()){
				User user=new User();
				user.setUsername(rs.getString(2));
				user.setGender(rs.getString(4));
				user.setEmail(rs.getString(5));
				user.setTelephone(rs.getString(6));
				list.add(user);
			}
			return list;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(rs, preStat, con);
		}
		return null;
	}
	public User findByName(String name){
		User user=new User();
		try{
			con=MyConn.getConnection();
			String sql="select * from user where username=?";
			preStat=con.prepareStatement(sql);
			preStat.setString(1, name);
			rs=preStat.executeQuery();
			if(rs.next()){
				user.setUsername(rs.getString(2));
				user.setGender(rs.getString(4));
				user.setEmail(rs.getString(5));
				user.setTelephone(rs.getString(6));
			}
			return user;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(rs, preStat, con);
		}
		return null;
	}
	public int getCount() throws Exception {
		// TODO Auto-generated method stub
		String sql = "SELECT count(*) FROM user";
		con=MyConn.getConnection();
		PreparedStatement pst = con.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		rs.next();
		int count = rs.getInt(1);
		pst.close();
		return count;
	}
	public Boolean Login(String name,String pwd){
		try{
			con=MyConn.getConnection();
			String sql="select * from user where username=? and PASSWORD=?";
			preStat=con.prepareStatement(sql);
			preStat.setString(1, name);
			preStat.setString(2, pwd);
			rs=preStat.executeQuery();
			if(rs.next()){
				return true;
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(rs, preStat, con);
		}
		return false;
	}
	public boolean insert(User user){
		try{
			con=MyConn.getConnection();
			String sql="insert into user(username,gender,email,telephone) values(?,?,?,?)";
			preStat=con.prepareStatement(sql);
			preStat.setString(1, user.getUsername());
			preStat.setString(2, user.getGender());
			preStat.setString(3, user.getEmail());
			preStat.setString(4, user.getTelephone());
	
			if(preStat.executeUpdate()==1) return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(preStat, con);
		}
		return false;
	}
	public boolean update(User user){
		try{
			con=MyConn.getConnection();
			String sql="update user set gender=?,email=?,telephone=? where username=?";
			preStat=con.prepareStatement(sql);
			preStat.setString(1, user.getGender());
			preStat.setString(2, user.getEmail());
			preStat.setString(3, user.getTelephone());
			preStat.setString(4, user.getUsername());
			if(preStat.executeUpdate()==1) return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(preStat, con);
		}
		return false;
	}
	public boolean delete(String name){
		try{
			con=MyConn.getConnection();
			String sql="delete from user where username=?";
			preStat=con.prepareStatement(sql);
			preStat.setString(1, name);
			if(preStat.executeUpdate()==1) return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			MyConn.release(preStat, con);
		}
		return false;
	}
}
