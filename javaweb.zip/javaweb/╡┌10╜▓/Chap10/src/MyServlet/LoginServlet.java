package MyServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javabean.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao2;

public class LoginServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the GET method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String code = request.getParameter("code");//验证码
		String account = request.getParameter("userid");//帐号
		String password = request.getParameter("password");//密码
    	String type = request.getParameter("type"); //身份（教师或者学生）
    	
    	String savedCode = (String) request.getSession().getAttribute("check_code");

    	/*1.验证码输入要正确*/
		if(code.equals(savedCode)){
			/*2.帐号输入不能为空*/
			if(account!=null && !account.equals("")){
				/*3.1 学生登录*/
				if(type.equals("student")){ 
					//StudentDao sdao = new StudentDaoImpl();
				
				}
				/*3.2 教师登录*/
				else if(type.equals("teacher")){ 
					//TeacherDao tdao = new TeacherDaoImpl();
					type = "教师";
				}
				else 
					if(type.equals("user")){ 
					UserDao2 userdao = new UserDao2();
					type = "管理员";
				    boolean falg=userdao.Login(account, password);
					if(falg==false){
						request.setAttribute("msg1", "帐号或密码输入有误,登录失败！");
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
						dispatcher.forward(request, response); 
					}else{
						request.getSession().setAttribute("userid",account);
						request.getSession().setAttribute("type",type);
						response.sendRedirect("/Chap10/user_ope.jsp");
					}
			}
		}
		/*4.验证码错误处理*/
		else{
			request.setAttribute("msg1", "验证码输入错误,登录失败!");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
			dispatcher.forward(request, response); 
		}
	}	
		
		
		
		
		
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
