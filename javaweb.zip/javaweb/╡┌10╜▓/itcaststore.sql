/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50096
Source Host           : localhost:3306
Source Database       : itcaststore

Target Server Type    : MYSQL
Target Server Version : 50096
File Encoding         : 65001

Date: 2022-04-21 14:17:52
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `book`
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `bookid` varchar(255) NOT NULL,
  `bookname` varchar(255) default NULL,
  `bookimage` varchar(255) default NULL,
  `bookfujian` varchar(255) default NULL,
  `people` varchar(255) default NULL,
  PRIMARY KEY  (`bookid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('0001', '第一章', null, '111.ppt', 'admin');
INSERT INTO `book` VALUES ('0002', '第二讲', null, '222.pptx', 'admin');
INSERT INTO `book` VALUES ('0003', '第三讲', null, '333.pptx', 'lhx');
INSERT INTO `book` VALUES ('0004', 'aaa', null, 'aaa.pptx', 'admin');

-- ----------------------------
-- Table structure for `orders`
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` varchar(100) NOT NULL,
  `money` double default NULL,
  `receiverAddress` varchar(255) default NULL,
  `receiverName` varchar(20) default NULL,
  `receiverPhone` varchar(20) default NULL,
  `paystate` int(11) default '0',
  `ordertime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('0c0796f2-0124-4a13-a891-5efbb63b04f9', '44.5', '北京市昌平区金燕龙办公楼', 'hanyongmeng', '15207545526', '1', '2016-05-18 10:36:36', '4');
INSERT INTO `orders` VALUES ('305a7870-3820-4079-b6f9-5d2b63cbcd2a', '59', '北京市昌平区建材城西路金燕龙办公楼', 'huangyun', '13041019968', '0', '2016-01-13 15:14:54', '3');
INSERT INTO `orders` VALUES ('611f80fa-4273-4674-be09-9530b6276e15', '89', '北京市海淀区清河永泰园5号楼501', 'huangyun', '13041019968', '1', '2016-01-10 18:00:36', '3');
INSERT INTO `orders` VALUES ('677a7314-0e16-4e18-8aec-552f848e0d75', '65', '北京市昌平区', 'hanyongmeng', '15207545526', '0', '2016-05-18 11:33:25', '4');
INSERT INTO `orders` VALUES ('6f591522-7a2a-4a31-899d-ef1181c72f5f', '25', '北京市昌平区金燕龙办公楼一层传智播客', 'madan', '13269219270', '0', '2016-01-10 18:00:36', '2');
INSERT INTO `orders` VALUES ('7ae96e6d-4600-41a5-bc5d-143b34ba61db', '35', '北京市昌平区建材城西路', 'madan', '13269219270', '0', '2016-02-25 10:44:56', '2');
INSERT INTO `orders` VALUES ('a5bfb13d-9085-4374-94d9-4864b4d618ab', '25', '海淀区圆明园西路', 'hanyongmeng', '13455260812', '1', '2016-02-25 10:43:40', '4');
INSERT INTO `orders` VALUES ('c4b2bfff-1694-4e28-bcf8-fa7169bfc978', '129', '北京市昌平区北七家镇', 'hanyongmeng', '15207545526', '1', '2016-05-18 10:36:22', '4');
INSERT INTO `orders` VALUES ('d88d75cd-15e3-4622-801d-4cad902aeaa1', '25', '北京市昌平区建材城西路金燕龙办公楼', 'hanyongmeng', '13848399998', '1', '2016-02-25 10:44:23', '4');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `PASSWORD` varchar(20) default '123456',
  `gender` varchar(10) default NULL,
  `email` varchar(50) default NULL,
  `telephone` varchar(20) default NULL,
  `introduce` varchar(100) default NULL,
  `activeCode` varchar(50) default NULL,
  `state` int(11) default '0',
  `role` varchar(10) default '普通用户',
  `registTime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', '123456', '男', 'huan9yun@163.com', '13041019968', '我是超级管理员，我可以登录后台管理系统', '49338fdc-d8c9-46fa-8391-0fac7bf09707', '1', '超级用户', '2015-03-19 16:16:40');
INSERT INTO `user` VALUES ('3', 'huangyun', '123456', '男', 'huan9yun@163.com', '13041019968', '大家好，我是黄云', 'd0827d1d-dc0d-4cdc-8710-678ce917880e', '1', '普通用户', '2015-03-20 17:36:38');
INSERT INTO `user` VALUES ('4', 'hanyongmeng', '123456', '男', 'itcast_hym@163.com', '15207545526', '课程设计师', 'da483412-1e34-43cf-aef2-4925748c811d', '1', '普通用户', '2016-01-21 15:19:32');
INSERT INTO `user` VALUES ('5', 'tianjiao', '123456', '男', 'hanyongmeng@126.cn', '123456', '', 'f8173f4f-debe-4d32-8117-b228d555d822', '0', '普通用户', '2022-01-20 01:51:21');
INSERT INTO `user` VALUES ('7', 'bbb', '123456', '男', '46437', '68679870', null, null, '0', '普通用户', '2022-01-20 04:04:12');
INSERT INTO `user` VALUES ('8', 'dddd', 'dddd', '女', 'dddd', 'dddd', 'dddd', null, '0', '普通用户', '2022-01-20 04:05:50');
